import Head from 'next/head';
import Landing from '../components/Landing';
import Problem from '../components/Problem';
import Solution from '../components/Solution';
import Technical from '../components/Technical';
import Impact from '../components/Impact';
import Community from '../components/Community';
import Circular from '../components/Circular';
import Market from '../components/Market';
import Roadmap from '../components/Roadmap';
import TechStack from '../components/TechStack';
import Future from '../components/Future';
import Contact from '../components/Contact';

export default function Home() {
  return (
    <>
      <Head>
        <title>RePLASTIX | Turning Waste into Sustainable Infrastructure</title>
        <meta name="description" content="Recycling plastic into modular building solutions" />
      </Head>
      <main className="font-sans bg-gray-50 text-gray-900">
        <Landing />
        <Problem />
        <Solution />
        <Technical />
        <Impact />
        <Community />
        <Circular />
        <Market />
        <Roadmap />
        <TechStack />
        <Future />
        <Contact />
      </main>
    </>
  );
}
