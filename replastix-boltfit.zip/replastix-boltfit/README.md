# RePLASTIX Site

A static Next.js frontend website for the RePLASTIX project: Turning plastic waste into sustainable bricks.

## 🚀 Quick Start

```bash
npm install
npm run build
npm run export
```

## 🧩 Deployment

Use [BoltFit](https://bolt.fit) and upload the `boltprompt.yaml` file to deploy easily.
